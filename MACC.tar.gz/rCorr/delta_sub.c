#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define a_0 (1.L)
#define pi (3.1415926535L)
#define Onethird (1.L/3.L)
#define Twothird (2.L/3.L)

double qsimp(double (*func)(double), double , double );
double trapzd(double (*func)(double), double , double , int);
double omega;
double omega_m;
double delta_0;
double kappa;
double kappamin;
double rta,theta,s;
double func1(double x){
	double result;
	result = pow(x/(x*x*x+2.L),1.5L);
	return result;
}
double integral1(double x){
	double result;
	result = qsimp(func1,0.L,x);
	return result;
}
double A(double x){
	double result;
	result = sqrt(x*x*x+2.L)/pow(x,1.5L) * integral1(x);
	return result;
}
double D(double a){
	double result;
	double tmp1,tmp2;
	tmp1 = a*pow(2.L*omega,Onethird);
	tmp2 = a_0*pow(2.L*omega,Onethird);
	result = A(tmp1)/A(tmp2);
	return result;
}
double func2(double x){
	double result;
	result = sqrt(x)/sqrt((omega*x*x*x-kappa*x+1.L));
	return result;
}
double I(){
	double result;
	result = qsimp(func2,0.L,rta);
	return result;
}
double ata(){
	double result;
	double tmp;
	tmp = I();
	result = pow((exp(3.L*sqrt(omega)*tmp)-1.L)/(2.L*sqrt(omega)),Twothird)*
		exp(-1.L*sqrt(omega)*tmp);
	return result;
}
double ac(){
	double result;
	double tmp;
	tmp = I();
	result = pow((exp(6.L*sqrt(omega)*tmp)-1.L)/(2.L*sqrt(omega)),Twothird)*
		exp(-2.L*sqrt(omega)*tmp);
	return result;
}

double func3(double x){
	double result;
	result = sqrt(x/(omega*x*x*x+1.L));
	return result;
}
double J(){
	double result;
	result = qsimp(func3,0.L,ata());
	return result;
}
/* Eke et al. 1996, MNRAS, 282,263  "Cluster evolution 
 * as a diagnostic for Omega
 * */
void delta_(float *Omega,float *Lambda,  float *result1){
	int i,j,k;
	double result;
	double tmp,tmp1;
	double lambda,omega_k;
	omega_m = *Omega;
	lambda = *Lambda;
	if(omega_m == 1.) {
		omega_m = 0.9999;
		lambda = 1-omega_m;
	}
	omega_k = 1.-omega_m-lambda;
	if(fabs(omega_k) >= 0.00001) {
		fprintf(stderr,"input as omega_m+ omega_l = 1\n");
		exit(99);
	}
	delta_0 = 178.L;

	/*
	for(i=1;i<100;i++){
		omega_m = 1.L-1.L/100.L*(double)i;
	*/
		omega = 1.L/omega_m - 1.L;
		tmp = a_0*pow(2.L*omega,Onethird);
		kappa = a_0*pow(2.L*omega,Onethird)*delta_0/
			(3.L*A(tmp));
		kappamin = 3.L*pow(omega,Onethird)/pow(2.L,Twothird);
		theta = acos(pow(kappamin/kappa,1.5L));
		s = pow(1.5L,3.L)*pow(kappa/pow(kappamin,3.L),1.5L);
		rta = -2.L*pow(s,Onethird)*cos(theta/3.L-2.L*pi/3.L);
		result = delta_0*D(ac());
		/*
		printf("Omega_m = %g ,re =%g",omega_m,result);
		*/
		tmp1 = 1./0.9999-1.;
		/*
		printf(", D0 = %g ",A(pow(2.L*omega,Onethird))/pow(omega,Onethird)/
				A(pow(2.L*tmp1,Onethird))*pow(tmp1,Onethird));
		printf("I() = %g ,J() =%g\n",I(),J());
	}
	*/
		*result1 = (float )result;
		/*
	return result1;
	*/
}
#define FUNC(x) ((*func)(x))
double trapzd(double (*func)(double), double a, double b, int n)
{
	double x,tnm,sum,del;
	static double s;
	int it,j;

	if (n == 1) {
		return (s=0.5L*(b-a)*(FUNC(a)+FUNC(b)));
	} else {
		for (it=1,j=1;j<n-1;j++) it <<= 1;
		tnm=it;
		del=(b-a)/tnm;
		x=a+0.5L*del;
		for (sum=0.0L,j=1;j<=it;j++,x+=del) sum += FUNC(x);
		s=0.5L*(s+(b-a)*sum/tnm);
		return s;
	}
}
#undef FUNC
/* (C) Copr. 1986-92 Numerical Recipes Software 71.+I0>+. */
#include <math.h>
#define EPS 1.0e-5L
#define JMAX 25

double qsimp(double (*func)(double), double a, double b)
{
	double trapzd(double (*func)(double), double a, double b, int n);
	int j;
	double s,st,ost,os;

	ost = os = -1.0e30L;
	for (j=1;j<=JMAX;j++) {
		st=trapzd(func,a,b,j);
		s=(4.0L*st-ost)/3.0L;
		if (fabs(s-os) < EPS*fabs(os)) return s;
		os=s;
		ost=st;
	}
	nrerror("error\n");
	return 0.0L;
}
#undef EPS
#undef JMAX
/* (C) Copr. 1986-92 Numerical Recipes Software 71.+I0>+. */
